/* Generated SBE (Simple Binary Encoding) message codecs.*/
/**
 * A schema represents stock market data.
 */
package com.baeldung.sbe.stub;
